// Ganti nilai di bawah ini dengan akun / kontak NEXOGIL yang asli.
export const SITE = {
  name: 'NEXOGIL',
  // Format internasional tanpa "+" atau spasi, contoh: '6281234567890'.
  // Kosong = WhatsApp akan membuka pilihan kontak.
  whatsappNumber: '',
  email: 'support@nexogil.example',
  instagram: 'https://www.instagram.com/',
  tiktok: 'https://www.tiktok.com/',
}

export const whatsappLink = (text = '') =>
  `https://wa.me/${SITE.whatsappNumber}${text ? `?text=${encodeURIComponent(text)}` : ''}`
